# MGMT300-Summer2021

<b>Course name:</b> Quantitative Tools for Management (https://cbe.aua.am/course-description-2/)<br>
<b>Program:</b> Master of Science in Management<br>
<b>University:</b> American University of Armenia<br>
<b>The following programs were used:</b> EXCEL 2016 (or higher), Python 3.7, Jupyter Notebook, Tableau<br>
<b>Lecturer:</b> Parandzem Sargsyan
